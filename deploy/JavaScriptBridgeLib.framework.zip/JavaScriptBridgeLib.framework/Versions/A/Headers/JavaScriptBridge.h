//
//  JavaScriptBridge.h
//  JavaScriptBridge
//
//  Created by kishikawa katsumi on 2014/01/02.
//  Copyright (c) 2014 kishikawa katsumi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSBScriptingSupport.h"
